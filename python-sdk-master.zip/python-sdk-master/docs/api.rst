.. currentmodule:: topgg

#############
API Reference
#############

The following section outlines the API of topggpy.

Index:

 .. toctree::
    :maxdepth: 2

    api/autopost
    api/client
    api/data
    api/errors
    api/types
    api/webhook