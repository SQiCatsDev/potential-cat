####################
Errors API Reference
####################

.. automodule:: topgg.errors
    :members:
    :inherited-members: