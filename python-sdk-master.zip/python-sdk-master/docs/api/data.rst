##################
Data API Reference
##################

.. automodule:: topgg.data
    :members:
    :inherited-members: